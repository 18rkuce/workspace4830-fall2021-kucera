package p3.pullup_method.org;

public class Engineer extends Employee {
	private String name;

	String getName() {
		return this.name;
	}
}
